<?php

namespace MpcServices\Handlers\Grabber;

use DiDom\Element;
use MpcServices\Handlers\Parser;

/**
 * Извлечение значений из конкретных DOM-элементов.
 * Зависит от MediaDownloader и LexiconManager.
 */
class FieldValueExtractor
{
    private array $downloadMethodsByTagName = [
        'picture' => 'downloadImage',
        'video' => 'downloadVideo',
        'audio' => 'downloadAudio',
    ];

    private array $properties;
    private MediaDownloader $mediaDownloader;
    private LexiconManager $lexiconManager;
    private Parser $parser;

    /**
     * Решение о формате/лексиконизации listbox-поля, зафиксированное по ПЕРВОМУ
     * его элементу. В списке (MIGX) поле определяется один раз — последующие items
     * не должны переопределять опции/тип. Ключ — путь схемы без индексов строк
     * (options['schemaKey']); сбрасывается на каждую секцию (resetListboxDecisions).
     */
    private array $listboxDecisions = [];

    public function __construct(
        array $properties,
        MediaDownloader $mediaDownloader,
        LexiconManager $lexiconManager,
        Parser $parser
    ) {
        $this->properties = $properties;
        $this->mediaDownloader = $mediaDownloader;
        $this->lexiconManager = $lexiconManager;
        $this->parser = $parser;
    }

    public function getImageValue(Element $row, ?array $options = []): string
    {
        $attrs = ['src', 'alt', 'title', 'width', 'height'];
        $value[0]['MIGX_id'] = 1;
        $baseFieldName = $options['fieldName'] ?? '';

        foreach ($attrs as $attr) {
            $attrValue = $row->getAttribute($attr);

            if ($attr === 'src' && strpos($attrValue, 'http') !== false) {
                $attrValue = $this->mediaDownloader->downloadImage($attrValue);
            }
            if ($attr === 'src') {
                $attrValue = in_array('image', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($attrValue, $options) : $attrValue;
            }
            if ($attr === 'alt') {
                $options['fieldName'] = $baseFieldName . '_alt';
                $attrValue = in_array('text', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($attrValue, $options) : $attrValue;
            }
            if ($attr === 'title') {
                // Локальная копия: не мутируем общий $options (его поле alt уже
                // переписало на `_alt`, а ниже идут width/height без скоупа).
                $titleOptions = $options;
                $titleOptions['fieldName'] = $baseFieldName . '_title';
                $attrValue = in_array('text', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($attrValue, $titleOptions) : $attrValue;
            }
            $value[0][$attr] = $attrValue;
        }

        return json_encode($value, JSON_UNESCAPED_UNICODE);
    }

    public function getSourceValue(Element $row, ?int $idx = 1, ?bool $isPicture = true): array
    {
        $attrs = ['type', 'media'];
        if (!$isPicture) {
            $attrs[] = 'src';
        } else {
            $attrs = array_merge($attrs, ['srcset', 'sizes', 'height', 'width']);
        }

        $parent = $row->parent();
        if ($parent->tagName() === $row->tagName()) {
            $parent = $parent->parent();
        }

        $downloadMethod = $this->downloadMethodsByTagName[$parent->tagName()] ?? '';
        $value['MIGX_id'] = $idx;

        foreach ($attrs as $attr) {
            $attrValue = $row->getAttribute($attr);
            if (in_array($attr, ['srcset', 'src']) && strpos($row->getAttribute($attr), 'http') !== false) {
                $attrValue = method_exists($this->mediaDownloader, $downloadMethod)
                    ? $this->mediaDownloader->$downloadMethod($attrValue)
                    : $attrValue;
            }
            $value[$attr] = $attrValue;
        }

        return $value;
    }

    public function getPictureValue(Element $element, ?array $options = []): string
    {
        $picture[0]['MIGX_id'] = 1;
        $picture[0]['preview'] = '';
        $picture[0]['img'] = [];
        $picture[0]['sources'] = [];

        if ($img = $element->first('img')) {
            $picture[0]['img'] = $this->getImageValue($img, $options);
            $picture[0]['preview'] = $img->getAttribute('src');
        }

        if ($sources = $element->find('source')) {
            $options['parentFieldName'] = !empty($options['idx']) ? "{$options['fieldName']}_{$options['idx']}" : ($options['fieldName'] ?? '');
            $options['fieldName'] = 'source';
            foreach ($sources as $k => $source) {
                $options['idx'] = $k;
                $picture[0]['sources'][$k] = $this->getSourceValue($source, $k + 1);
                $picture[0]['sources'][$k]['srcset'] = in_array('image', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($picture[0]['sources'][$k]['srcset'], $options)
                    : $picture[0]['sources'][$k]['srcset'];
            }
        }

        return json_encode($picture);
    }

    public function getMediaValue(Element $element, ?array $options = []): array
    {
        $useLexicons = in_array('video', $this->properties['translatableContentTypes'])
            || in_array('audio', $this->properties['translatableContentTypes']);

        $media[0]['MIGX_id'] = 1;
        $attrs = [
            'src' => 'string',
            'title' => 'string',
            'autoplay' => 'boolean',
            'controls' => 'boolean',
            'loop' => 'boolean',
            'muted' => 'boolean',
            // preload — перечислимый (auto|metadata|none), а НЕ HTML-boolean:
            // храним строковое значение, иначе теряется (рендерится подстановкой).
            'preload' => 'string',
        ];

        if ($element->tagName() === 'video') {
            $attrs = array_merge($attrs, [
                'src' => 'string',
                'width' => 'number',
                'height' => 'number',
                'poster' => 'string',
            ]);
        }

        $media[0]['sources'] = [];
        foreach ($attrs as $attr => $type) {
            if ($type === 'boolean') {
                $media[0][$attr] = $element->hasAttribute($attr) ? 1 : 0;
            } else {
                $media[0][$attr] = $element->getAttribute($attr) ?: '';
            }

            if ($attr === 'poster') {
                if (strpos($media[0][$attr], 'http') !== false) {
                    $media[0][$attr] = $this->mediaDownloader->downloadImage($media[0][$attr]);
                }
                $parentFieldName = $this->getParentFieldName($options);
                $lexiconOptions = ['fieldName' => 'poster', 'parentFieldName' => $parentFieldName, 'idx' => 0];
                $media[0][$attr] = in_array('poster', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($media[0][$attr], $lexiconOptions)
                    : $media[0][$attr];
            }

            if ($attr === 'src') {
                if (strpos($media[0][$attr], 'http') !== false) {
                    $downloadMethod = $this->downloadMethodsByTagName[$element->tagName()] ?? '';
                    $media[0][$attr] = method_exists($this->mediaDownloader, $downloadMethod)
                        ? $this->mediaDownloader->$downloadMethod($media[0][$attr])
                        : $media[0][$attr];
                }
                $media[0][$attr] = $useLexicons
                    ? $this->lexiconManager->setLexicons($media[0][$attr], $options)
                    : $media[0][$attr];
            }

            if ($attr === 'title') {
                // title — человекочитаемый текст (тултип). Лексиконим как `text`
                // с суффиксом `_title` (симметрично alt). Локальная копия —
                // чтобы не задеть scope src/poster/sources, использующих $options.
                $titleOptions = $options;
                $titleOptions['fieldName'] = ($options['fieldName'] ?? '') . '_title';
                $media[0][$attr] = in_array('text', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($media[0][$attr], $titleOptions)
                    : $media[0][$attr];
            }
        }

        if ($sources = $element->find('source')) {
            $parentFieldName = $this->getParentFieldName($options);
            $lexiconOptions = ['fieldName' => 'source', 'parentFieldName' => $parentFieldName];
            foreach ($sources as $k => $source) {
                $lexiconOptions['idx'] = $k;
                $media[0]['sources'][$k] = $this->getSourceValue($source, $k + 1, false);
                $media[0]['sources'][$k]['src'] = $useLexicons
                    ? $this->lexiconManager->setLexicons($media[0]['sources'][$k]['src'], $lexiconOptions)
                    : $media[0]['sources'][$k]['src'];
            }
        }

        if (!$media[0]['src']) {
            $media[0]['src'] = $media[0]['sources'][0]['src'] ?? '';
        }

        return $media;
    }

    public function getBackgroundValue(Element $element, ?array $options = []): string
    {
        if ($style = $element->getAttribute('style')) {
            if (strpos($style, 'background') !== false) {
                // url() с любыми кавычками или без: группа 1 — открывающая кавычка
                // (\1 требует парной на закрытии), группа 2 — сам URL (индекс прежний).
                preg_match('/(?:background|background-image)\s*:.*?url\(\s*(["\']?)(.*?)\1\s*\)/is', $style, $matches);
                $value = $matches[2] ?? '';
                if (strpos($value, 'http') !== false) {
                    $value = $this->mediaDownloader->downloadImage($value);
                }
                return in_array('image', $this->properties['translatableContentTypes'])
                    ? $this->lexiconManager->setLexicons($value, $options) : $value;
            }
        }
        return '';
    }

    /**
     * Сброс зафиксированных решений listbox. Зовётся на границе секции
     * (ContentParser::getFieldsValues), чтобы одноимённые поля разных секций
     * не делили решение.
     */
    public function resetListboxDecisions(): void
    {
        $this->listboxDecisions = [];
    }

    /**
     * Решение о listbox-поле, зафиксированное по ПЕРВОМУ его элементу: тип опций
     * (data-mpc-values), множественность (data-mpc-ftype) и динамика (@SELECT).
     * В списке поле обрабатывается для каждого item, но определяется один раз —
     * последующие items берут это же решение (их innerHtml-значение остаётся своим).
     * Ключ — путь схемы без индексов строк (options['schemaKey']); вне списка
     * совпадает с именем поля.
     */
    private function listboxDecision(Element $element, array $options): array
    {
        $key = (string)($options['schemaKey'] ?? ($options['fieldName'] ?? ''));
        if (!isset($this->listboxDecisions[$key])) {
            $rawValues = (string)$element->getAttribute('data-mpc-values');
            $this->listboxDecisions[$key] = [
                'isListbox' => $rawValues !== '',
                'rawValues' => $rawValues,
                'multiple'  => OptionFieldHelper::isMultiOptionFtype((string)$element->getAttribute('data-mpc-ftype')),
                'dynamic'   => $rawValues !== '' && OptionFieldHelper::classifyListboxOptions($rawValues)['mode'] === 'dynamic',
            ];
        }
        return $this->listboxDecisions[$key];
    }

    /**
     * Множественность listbox-поля по зафиксированному (первому) решению —
     * для ContentParser (нормализация значения в "||"-набор ключей).
     */
    public function isMultiOptionField(Element $element, array $options): bool
    {
        return $this->listboxDecision($element, $options)['multiple'];
    }

    public function getValue(Element $element, ?array $options = []): string
    {
        // listbox (data-mpc-values): значение поля — СЫРОЙ ключ опции; капшены
        // опций уходят в лексикон ключами {prefix}_{field}_{optionKey}. Само
        // значение НЕ лексиконим как text-ключ (enum, не переводимый текст).
        // Решение (тип/опции/динамика) — по ПЕРВОМУ элементу поля (см. listboxDecision),
        // значение innerHtml берётся у текущего элемента.
        $decision = $this->listboxDecision($element, (array)$options);
        if ($decision['isListbox']) {
            $result   = trim($element->innerHtml());
            $rawValues = $decision['rawValues'];
            $multiple  = $decision['multiple'];
            // Динамические опции (@SELECT …): реальные значения приходят из БД
            // (id / алиас ресурса / произвольная строка) — их НЕЛЬЗЯ нормализовать
            // (нормализация порежет алиас: дефисы, регистр, не-латиницу) и нечего
            // лексиконить (капшенов в data-mpc-values нет). Значение — как есть.
            if ($decision['dynamic']) {
                return $result;
            }
            // Капшены опций → лексикон (и одиночный, и мультивыбор). Значение поля
            // остаётся сырым (для multiple ContentParser разобьёт его в массив ключей,
            // чтобы $field был iterable в Fenom).
            $this->lexiconManager->writeListboxOptions(
                (string)($options['fieldName'] ?? ''),
                (string)($options['parentFieldName'] ?? ''),
                $rawValues,
                $result,
                $multiple
            );
            // Выбранное значение → нормализованная форма (совпадает с ключами опций
            // и с inputOptionValues; рендер строит ключ лексикона из этого значения).
            return OptionFieldHelper::normalizeListboxValue($result, $multiple);
        }

        if ($href = $element->getAttribute('href')) {
            $result = $href;
        } elseif ($children = $element->children()) {
            $tmp = [];
            foreach ($children as $childNode) {
                $tmp[] = trim($this->parser->getHTMLString($childNode));
            }
            $result = implode(' ', $tmp);
        } else {
            $result = trim($element->innerHtml());
        }

        return in_array('text', $this->properties['translatableContentTypes']) && !empty($options)
            ? $this->lexiconManager->setLexicons($result, $options) : $result;
    }

    public function getParentFieldName(array $options): string
    {
        $fieldName = $options['fieldName'] ?? '';
        $parentFieldName = $options['parentFieldName'] ?? '';
        $idx = $options['idx'] ?? 0;

        if ($parentFieldName) {
            return $idx
                ? $parentFieldName . '_' . "{$fieldName}_{$idx}"
                : $parentFieldName . '_' . $fieldName;
        }
        return $idx ? "{$fieldName}_{$idx}" : $fieldName;
    }
}
