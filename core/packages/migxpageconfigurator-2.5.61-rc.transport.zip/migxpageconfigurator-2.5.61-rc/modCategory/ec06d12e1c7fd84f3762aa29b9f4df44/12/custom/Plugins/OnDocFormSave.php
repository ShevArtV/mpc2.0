<?php

/**
 * Сервис для обработки события OnDocFormSave
 */

namespace MpcServices\Plugins;

use MpcServices\Mpc;

/**
 * @author Arthur Shevchenko (https://t.me/ShevArtV)
 */
class OnDocFormSave extends PluginHandler
{
    /**
     * @return void
     */
    public function run(): void
    {
        // Аудит правок из админки в лог изменений — ДО re-cut (handleFile его бы
        // перетёр своим ре-грабом). Диффит со снимком OnBeforeDocFormSave.
        $resource = $this->scriptProperties['resource'] ?? null;
        if (!$resource instanceof \modResource) {
            return; // событие без ресурса (или не modResource) — нечего обрабатывать
        }
        (new \MpcServices\Handlers\AdminAudit($this->modx))->logChanges(
            $resource,
            (int)$this->modx->getOption('mpc_static_block_page_id', null, 1)
        );

        $ctx = $resource->get('context_key');
        if ($this->modx->context->get('key') !== $ctx) {
            $this->modx->switchContext($ctx);
        }
        $Mpc = new Mpc($this->modx);
        $Mpc->render->copyConfig($this->scriptProperties['resource']);
        $Mpc->grabber->fromPlugin = true;
        if ($typeResource = $this->modx->getObject('modResource', [
            'template' => $this->scriptProperties['resource']->get('template'),
            'parent' => $Mpc->cutter->properties['staticBlocksPageId']
        ])) {
            // Имя файла типа: новое каноничное поле file_name (mpc_type),
            // фоллбэк на introtext для ещё не перенарезанных типов.
            $fileName = $typeResource->get('file_name') ?: $typeResource->get('introtext');
            $Mpc->cutter->staticSectionNames = $Mpc->grabber->staticSectionNames = $Mpc->cutter->getStaticSectionNames($this->scriptProperties['id']);
            $Mpc->handleFile($fileName);

            if($typeResource->get('id') !== $this->scriptProperties['id']){
                $this->manageResourceLexicons($this->scriptProperties['resource'], $Mpc, $typeResource->get('id'));
            }
        }
        if ($this->scriptProperties['id'] === $Mpc->grabber->properties['staticBlocksPageId']) {
            $this->filterStaticSectionsLexicons($Mpc);
        }
        if ($this->scriptProperties['id'] === $Mpc->grabber->properties['contactsPageId']) {
            $this->filterContactsLexicons($Mpc);
        }

        // Сносим parsed: нестатичные секции держат ЗАПЕЧЁННЫЕ значения, а файл
        // регенерится только при отсутствии. Правка ресурса-ТИПА (донор, parent =
        // staticBlocksPage) влияет на наследующие → сносим весь parsed; иначе —
        // файл этого ресурса.
        $sbp = (int)$Mpc->cutter->properties['staticBlocksPageId'];
        if ((int)$this->scriptProperties['resource']->get('parent') === $sbp) {
            $Mpc->render->clearCache();
        } else {
            $Mpc->render->deleteParsedConfigFile((int)$this->scriptProperties['id']);
        }
    }

    /**
     * @param Mpc $Mpc
     * @return void
     */
    public function filterStaticSectionsLexicons(Mpc $Mpc): void
    {
        $staticBlocksPageId = $Mpc->grabber->properties['staticBlocksPageId'];
        $staticBlocksPageLexiconFilename = $Mpc->grabber->properties['staticBlocksPageLexiconFilename'];
        $lexicons[$staticBlocksPageLexiconFilename] = $Mpc->grabber->getLexicons($staticBlocksPageLexiconFilename, $Mpc->grabber->properties['basePathToLexiconFile']);
        if (empty($lexicons[$staticBlocksPageLexiconFilename])) {
            return;
        }
        $resource = $this->modx->getObject('modResource', $staticBlocksPageId);
        if (!$resource || !$config = $resource->getTVValue($Mpc->grabber->properties['commonConfigTvName'])) {
            return;
        }
        $lexiconsFiltered[$staticBlocksPageLexiconFilename] = [];
        $config = json_decode($config, true);
        foreach ($config as $item) {
            $result = $this->filterByPrefix($lexicons[$staticBlocksPageLexiconFilename], $item['lexicon_prefix'] ?? $item['MIGX_formname']);
            $lexiconsFiltered[$staticBlocksPageLexiconFilename] = array_merge($result, $lexiconsFiltered[$staticBlocksPageLexiconFilename]);
        }

        $Mpc->grabber->createLexicons($lexiconsFiltered);
    }

    /**
     * @param Mpc $Mpc
     * @return void
     */
    public function filterContactsLexicons(Mpc $Mpc): void
    {
        $contactsPageId = $Mpc->grabber->properties['contactsPageId'];
        $contactsPageLexiconFilename = $Mpc->grabber->properties['contactsPageLexiconFilename'];
        $lexicons[$contactsPageLexiconFilename] = $Mpc->grabber->getLexicons($contactsPageLexiconFilename, $Mpc->grabber->properties['basePathToLexiconFile']);
        if (empty($lexicons[$contactsPageLexiconFilename])) {
            return;
        }
        $resource = $this->modx->getObject('modResource', $contactsPageId);
        if (!$resource || !$contacts = $resource->getTVValue($Mpc->grabber->properties['contactsTvName'])) {
            return;
        }
        $lexiconsFiltered[$contactsPageLexiconFilename] = [];
        $config = json_decode($contacts, true);
        foreach ($config as $item) {
            $result = $this->filterByPrefix($lexicons[$contactsPageLexiconFilename], 'contact_'.$item['ckey']);
            $lexiconsFiltered[$contactsPageLexiconFilename] = array_merge($result, $lexiconsFiltered[$contactsPageLexiconFilename]);
        }

       $Mpc->grabber->createLexicons($lexiconsFiltered);
    }

    /**
     * @param \modResource $resource
     * @param Mpc $Mpc
     * @param int $typeResourceId
     * @return void
     */
    private function manageResourceLexicons(\modResource $resource, Mpc $Mpc, int $typeResourceId): void
    {
        if (!$Mpc->grabber->properties['useLexicons']) {
            return;
        }

        if (!$config = $resource->getTVValue($Mpc->grabber->properties['commonConfigTvName'])) {
            return;
        }
        $config = json_decode($config, true);
        $resourceLexiconFilename = $Mpc->grabber->getResourceIdentifierById($resource->get('id'));
        $typeResourceLexiconFilename = $Mpc->grabber->getResourceIdentifierById($typeResourceId);
        $staticBlocksPageLexiconFilename = $Mpc->grabber->properties['staticBlocksPageLexiconFilename'];
        $lexicons[$resourceLexiconFilename] = $Mpc->grabber->getLexicons($resourceLexiconFilename, $Mpc->grabber->properties['basePathToLexiconFile']);
        $lexicons[$staticBlocksPageLexiconFilename] = $Mpc->grabber->getLexicons($staticBlocksPageLexiconFilename, $Mpc->grabber->properties['basePathToLexiconFile']);

        $allGrabberLexicons = array_merge(...array_values($Mpc->grabber->lexicons ?: [[]]));

        foreach ($config as $item) {
            $prefix = $item['lexicon_prefix'] ?? $item['MIGX_formname'];
            $result = $this->filterByPrefix($allGrabberLexicons, $prefix);
            if ($item['is_static']) {
                $lexicons[$staticBlocksPageLexiconFilename] = array_merge($result, $lexicons[$staticBlocksPageLexiconFilename]);
                // Секция статична → её переводы живут на уровне page-types. При
                // рендере ресурсный лексикон перебивает page-types (resource > type
                // в Mpc::getLexiconFilenames), поэтому осиротевшие ключи этой секции
                // в ресурсном файле НАДО вычистить — иначе они маскируют значения из
                // page-types (значение «прилипало» к ресурсу после перевода секции в
                // статику). $lexicons[resource] засеян всем старым содержимым файла с
                // диска (выше), а createLexicons перепишет файл этим массивом.
                $lexicons[$resourceLexiconFilename] = array_diff_key(
                    $lexicons[$resourceLexiconFilename],
                    $this->filterByPrefix($lexicons[$resourceLexiconFilename], $prefix)
                );
            } else {
                $lexicons[$resourceLexiconFilename] = array_merge($result, $lexicons[$resourceLexiconFilename]);
            }
        }
        $Mpc->grabber->createLexicons($lexicons);
    }

    /**
     * @param array $array
     * @param string $prefix
     * @return array
     */
    private function filterByPrefix(array $array, string $prefix): array
    {
        return array_filter($array, function ($key) use ($prefix) {
            return strpos($key, $prefix) === 0;
        }, ARRAY_FILTER_USE_KEY);
    }
}
